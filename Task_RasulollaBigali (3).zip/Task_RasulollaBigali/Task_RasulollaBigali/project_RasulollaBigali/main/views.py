from django.shortcuts import render

def home(request):
    return render(request, 'main/index.html')

def about(request):
    return render(request, 'main/about.html')

def resume(request):
    return render(request, 'main/resume.html')